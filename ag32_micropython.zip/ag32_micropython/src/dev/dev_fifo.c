#include "dev_fifo.h"


static uint16_t dev_fifo_read(dev_fifo * dev,uint8_t * data,uint16_t length) ;
static uint8_t dev_fifo_write(dev_fifo * dev,uint8_t * data,uint16_t length) ;
static void * dev_fifo_ioctl(dev_fifo * dev,int ioctl_word,void * param) ;

dev_fifo *  dev_fifo_init(void)
{
	dev_fifo * obj = malloc(sizeof(dev_fifo)) ;
	obj->buff = NULL ;
	obj->length = 0 ;
	obj->start_p = 0 ;
	obj->end_p = 0 ;
	obj->size = 0 ;
    obj->ops->read = dev_fifo_read ;
    obj->ops->write = dev_fifo_write ;
    obj->ops->ioctl = dev_fifo_ioctl ;
	return obj;
}

/*
* fifo 取出数据，返回 1 正常 0 空
*/

static uint16_t dev_fifo_read(dev_fifo * dev,uint8_t * data,uint16_t length)
{
    if(dev->length){
		*data = dev->buff[dev->end_p] ;
		dev->end_p += 1 ;
		if(dev->end_p == dev->size){
			dev->end_p = 0 ;
		}
		dev->length -= 1 ;
		return 1 ;
	}else{
		return 0 ;
	}
}
/*
* fifo 压入数据，返回 1 正常 0 满
*/
static uint8_t dev_fifo_write(dev_fifo * dev,uint8_t * data,uint16_t length)
{
	uint8_t ret = 0 ;
	if(dev->length != dev->size){
		ret = 0 ;
		dev->length += 1 ;
	}else{
		ret = 1 ;
	}
	dev->buff[dev->start_p] = *data ;
	dev->start_p += 1 ;
	if(dev->start_p == dev->size){
		dev->start_p = 0 ;
	}
	return ret ;
}


static void * dev_fifo_ioctl(dev_fifo * dev,int ioctl_word,void * param)
{
    switch (ioctl_word)
    {
    case DEV_FIFO_IOCTL_SETSIZE:{
        uint16_t size = (uint16_t)param ;
        if(dev->buff == NULL){
            dev->buff = malloc(size) ;
            dev->size = size ;
        }
        break;
    }
    default:
        break;
    }
}





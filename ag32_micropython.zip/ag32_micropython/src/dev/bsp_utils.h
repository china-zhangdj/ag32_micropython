#ifndef _BSP_UTILS_H_
#define _BSP_UTILS_H_

#include "stdint.h"

#ifdef __cplusplus
extern "c" 
{
#endif

uint16_t bsp_utils_crc_table(uint8_t *ptr,uint16_t len) ;


#ifdef __cplusplus
}
#endif



#endif


#ifndef DEV_DEFINE_H_
#define DEV_DEFINE_H_

#include <stdint.h>

/* start 公共宏定义 */
#define device_preinit(dev,...)     		dev->ops->preinit(dev,##__VA_ARGS__)
#define device_read(dev,...)     			dev->ops->read(dev,##__VA_ARGS__)
#define device_write(dev,...)    			dev->ops->write(dev,##__VA_ARGS__)
#define device_ioctl(dev,...)  				dev->ops->ioctl(dev,##__VA_ARGS__)
/* end 公共宏定义 */

/* start 公共结构体定义 */
typedef struct dev_class * dev_class_t;

typedef struct {
	unsigned char (*preinit)(dev_class_t dev);
	uint16_t (*read)(dev_class_t dev,void *val,uint16_t len);
	uint16_t (*write)(dev_class_t dev,const void *val,uint16_t len);
	void * (*ioctl)(dev_class_t dev,int ioctl_word,void * param);
}	dev_ops;

struct dev_class{
    dev_ops * ops;
    void *user_data;
};
/* end 公共结构体定义 */


#endif /* DEV_DEFINE_H_ */

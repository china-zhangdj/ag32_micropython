#include "bsp_fifo.h"

bsp_fifo_class * bsp_fifo_init(uint16_t size)
{
	bsp_fifo_class * obj = malloc(sizeof(bsp_fifo_class)) ;
	obj->buff = malloc(size) ;
	printf("buff=%p",obj->buff) ;
	obj->length = 0 ;
	obj->start_p = 0 ;
	obj->end_p = 0 ;
	obj->size = size ;
	return obj;
}

/*
* fifo 取出数据，返回 1 正常 0 空
*/
uint8_t bsp_fifo_pop(bsp_fifo_class * obj,uint8_t * data)
{
	if(obj->length){
		*data = obj->buff[obj->end_p] ;
		obj->end_p += 1 ;
		if(obj->end_p == obj->size){
			obj->end_p = 0 ;
		}
		obj->length -= 1 ;
		return 1 ;
	}else{
		return 0 ;
	}
}

/*
* fifo 压入数据，返回 1 正常 0 满
*/
uint8_t bsp_fifo_push(bsp_fifo_class * obj,uint8_t * data)
{
	uint8_t ret = 0 ;
	if(obj->length != obj->size){
		// not full 
		ret = 0 ;
		obj->length += 1 ;
	}else{
		ret = 1 ;
	}
	obj->buff[obj->start_p] = *data ;
	obj->start_p += 1 ;
	if(obj->start_p == obj->size){
		obj->start_p = 0 ;
	}
	return ret ;
}

/*
uint8_t bsp_fifo_push(bsp_fifo_class * obj, uint8_t * data) {
    if (obj->length == obj->size) {
        return 0; // 缓冲区满，返回失败
    }
    obj->buff[obj->start_p] = *data;
    obj->start_p = (obj->start_p + 1) % obj->size; // 循环索引
    obj->length += 1;
    return 1; // 成功
}
*/

/*
// 读取（不清除）
// 返回 读取的长度
uint8_t bsp_fifo_read(bsp_fifo_class * obj,uint8_t * data,uint16_t length)
{
	uint16_t read_length = 0 ; 
	uint16_t pointer ;
	uint16_t data_p ;
	if(length > obj->length){
		read_length = obj->length ;
	}else{
		read_length = length ;
	}
	
	if(read_length == 0) return 0 ;
	
	if(obj->start_p == 0){
			pointer = obj->size - 1 ;
	}else{
			pointer = obj->start_p - 1 ;
	}
	data_p = read_length - 1 ;
	
	data[data_p] = obj->buff[pointer] ;
	
	for(int i = 0 ; i < (read_length - 1); i ++){
		if(pointer == 0){
			pointer = obj->size - 1 ;
		}else{
			pointer -= 1 ;
		}
		data_p -= 1 ;
		data[data_p] = obj->buff[pointer] ;
	}
	
	return read_length ;
}

*/


uint8_t bsp_fifo_read(bsp_fifo_class * obj, uint8_t * data, uint16_t length) {
    uint16_t read_length = (length > obj->length) ? obj->length : length;
    if (read_length == 0) return 0;

    uint16_t pointer = obj->end_p; // 从最早的数据开始读
    for (int i = 0; i < read_length; i++) {
        data[i] = obj->buff[pointer];
        pointer = (pointer + 1) % obj->size; // 循环索引
    }
    return read_length;
}





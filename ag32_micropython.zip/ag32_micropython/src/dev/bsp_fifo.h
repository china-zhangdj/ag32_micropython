#ifndef _BSP_FIFO_H_
#define _BSP_FIFO_H_

#include "stdint.h"
#include "stdio.h"
#include "malloc.h"

#ifdef __cplusplus
extern "c" 
{
#endif

typedef struct _bsp_fifo_c {
	uint8_t * buff ;
	uint16_t start_p ;
	uint16_t end_p ;
	uint16_t length ;
	uint16_t size ;
} bsp_fifo_class ;

bsp_fifo_class * bsp_fifo_init(uint16_t size) ;
uint8_t bsp_fifo_pop(bsp_fifo_class * obj,uint8_t * data) ;
uint8_t bsp_fifo_push(bsp_fifo_class * obj,uint8_t * data) ;
uint8_t bsp_fifo_read(bsp_fifo_class * obj,uint8_t * data,uint16_t length) ;



#ifdef __cplusplus
}
#endif



#endif


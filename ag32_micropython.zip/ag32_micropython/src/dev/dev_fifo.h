#ifndef _BSP_FIFO_H_
#define _BSP_FIFO_H_

#include <stdlib.h>
#include <stdint.h>
#include "dev_define.h"

#ifdef __cplusplus
extern "c" 
{
#endif

typedef struct {
	uint8_t * buff ;
	uint16_t start_p ;
	uint16_t end_p ;
	uint16_t length ;
	uint16_t size ;
    dev_ops * ops ;
} dev_fifo ;


typedef enum {
    DEV_FIFO_IOCTL_SETSIZE = 0
}dev_fifo_ioctl_words ;

dev_fifo * dev_fifo_init(void) ;

#ifdef __cplusplus
}
#endif



#endif


#include <stdint.h>

// options to control how MicroPython is built

// Use the minimal starting configuration (disables all optional features).
#define MICROPY_CONFIG_ROM_LEVEL (MICROPY_CONFIG_ROM_LEVEL_CORE_FEATURES)

// You can disable the built-in MicroPython compiler by setting the following
// config option to 0.  If you do this then you won't get a REPL prompt, but you
// will still be able to execute pre-compiled scripts, compiled with mpy-cross.
#define MICROPY_ENABLE_COMPILER     (1)

#define MICROPY_QSTR_EXTRA_POOL           mp_qstr_frozen_const_pool
#define MICROPY_ENABLE_GC                 (1)
#define MICROPY_HELPER_REPL               (1)
#define MICROPY_MODULE_FROZEN_MPY         (2)
#define MICROPY_ENABLE_EXTERNAL_IMPORT    (1)
#define MICROPY_FLOAT_IMPL  MICROPY_FLOAT_IMPL_DOUBLE
#define MICROPY_PY_BUILTINS_BYTEARRAY (1)

#define MICROPY_PY_BUILTINS_HELP (1)
#define MICROPY_PY_BUILTINS_HELP_MODULES (1)

#define MICROPY_PY_SYS (1)
#define MICROPY_PY_SYS_MODULES (1)
#define MICROPY_PY_GC           (1)
#define MICROPY_PY_IO			(0)

#define MICROPY_PY_MATH		(1)
#define MICROPY_PY_UOS (0)

#define MICROPY_PY_URE (1)
#define MICROPY_PY_URE_SUB (1)
#define MICROPY_PY_URE_MATCH_GROUPS (1)
#define MICROPY_PY_URE_MATCH_SPAN_START_END (1)

#define MICROPY_PY_UJSON (0)
#define MICROPY_PY_UZLIB (0)
#define MICROPY_PY_UHEAPQ (0)
#define MICROPY_PY_URANDOM (1)
#define MICROPY_PY_USELECT (0)
#define MICROPY_PY_UHASHLIB (0)
#define MICROPY_PY_UBINASCII (0)
#define MICROPY_PY_UBINASCII_CRC32 (0)
#define MICROPY_PY_FRAMEBUF (0)
#define MICROPY_PY_UCTYPES (1)
#define MICROPY_PY_UASYNCIO (0)


#define MICROPY_PY_MACHINE (1)

#ifndef SSIZE_MAX
#define SSIZE_MAX INT_MAX
#endif

#define MICROPY_ALLOC_PATH_MAX            (256)
#define MICROPY_ALLOC_PARSE_CHUNK_INIT    (16)

// type definitions for the specific machine

typedef intptr_t mp_int_t; // must be pointer size
typedef uintptr_t mp_uint_t; // must be pointer size
typedef long mp_off_t;

// extra built in names to add to the global namespace
#define MICROPY_PORT_BUILTINS \
    { MP_ROM_QSTR(MP_QSTR_open), MP_ROM_PTR(&mp_builtin_open_obj) },

// We need to provide a declaration/definition of alloca()
#include <alloca.h>

#define MICROPY_HW_BOARD_NAME "AGEVB"
#define MICROPY_HW_MCU_NAME "AG32-FPGA"

#define MP_STATE_PORT MP_STATE_VM

#define MICROPY_PORT_ROOT_POINTERS \
    const char *readline_hist[8];

#define MICROPY_LONGINT_IMPL   MICROPY_LONGINT_IMPL_LONGLONG
